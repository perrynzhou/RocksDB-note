`installation_test.cc` is a demo on how to use PebblesDB. It also serves as a verification of the successful installation
of PebblesDB.

How to use it: `g++ installation_test.cc -lpebblesdb; ./a.out`